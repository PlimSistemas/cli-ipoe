#!/bin/sh

set -x -e
mkdir -p m4
autoreconf -fvi
