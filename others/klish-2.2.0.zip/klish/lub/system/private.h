/*
 * private.h
 */
#include "lub/types.h"
#include "lub/argv.h"
#include "lub/system.h"

int testcmd(int argc, char *argv[]);
