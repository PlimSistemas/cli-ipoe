/*
 * private.h
 */

#ifndef _clish_private_h
#define _clish_private_h

#include "lub/c_decl.h"

#endif /* _clish_private_h */
