/*
 * shell_misc.c
 */

#include <stdlib.h>
#include <assert.h>

#include "private.h"

CLISH_GET_STR(shell, overview);
