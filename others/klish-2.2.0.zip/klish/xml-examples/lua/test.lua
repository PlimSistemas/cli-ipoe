echo = print

shell = os.execute

function hello_world()
	print("Hello world from Lua!")
end
