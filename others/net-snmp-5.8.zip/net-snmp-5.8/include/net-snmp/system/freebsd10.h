/* freebsd10 is a superset of freebsd9 */
#include "freebsd9.h"
#define freebsd9 freebsd9
