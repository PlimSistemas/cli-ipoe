#include <net-snmp/net-snmp-config.h>
#include <net-snmp/net-snmp-features.h>

netsnmp_feature_require(snprint_objid)
netsnmp_feature_require(snprint_value)
netsnmp_feature_require(find_module)
netsnmp_feature_require(get_tc_description)

